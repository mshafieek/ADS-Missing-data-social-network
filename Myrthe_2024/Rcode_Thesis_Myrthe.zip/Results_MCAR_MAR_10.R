###### Running the REM on all simulations MCAR
Results1_MCAR_10 <- 
  mbased_finite_apollo_MCAR_10[1:10] %>% 
  map(~.x %>% # for every simulation
        complete("all") %>% 
        map(~.x %>% # for every imputation
              stats_function() %>% # do stats function
              prepare_coxph_data(apollo = .x) %$% # prepare coxph
              coxph(Surv(time, status) ~ 
                      reciprocity + 
                      indegreeSender + 
                      outdegreeReceiver + sameLoc)) %>%
        pool(custom.t = ".data$b + .data$b / .data$m") %>% # pool coefficients
        .$pooled %>% # extract table of pooled coefficients
        mutate(true = true, # add true
               df = m-1,  # correct df
               riv = Inf, # correct riv
               std.error = sqrt(t), # standard error
               statistic = estimate / std.error, # test statistic
               p.value = 2 * (pt(abs(statistic), 
                                 pmax(df, 0.001), 
                                 lower.tail = FALSE)), # correct p.value
               `2.5 %` = estimate - qt(.975, df) * std.error, # lower bound CI
               `97.5 %` = estimate + qt(.975, df) * std.error, # upper bound CI
               cov = `2.5 %` < true & true < `97.5 %`, # coverage
               bias = estimate - true) %>% # bias
        select(term, m, true, estimate, std.error, statistic, p.value, 
               riv, `2.5 %`, `97.5 %`, cov, bias) %>% 
        column_to_rownames("term") # `term` as rownames
  )

Results2_MCAR_10 <- 
  mbased_finite_apollo_MCAR_10[11:20] %>% 
  map(~.x %>% # for every simulation
        complete("all") %>% 
        map(~.x %>% # for every imputation
              stats_function() %>% # do stats function
              prepare_coxph_data(apollo = .x) %$% # prepare coxph
              coxph(Surv(time, status) ~ 
                      reciprocity + 
                      indegreeSender +
                      outdegreeReceiver + sameLoc)) %>%
        pool(custom.t = ".data$b + .data$b / .data$m") %>% # pool coefficients 
        .$pooled %>% # extract table of pooled coefficients
        mutate(true = true, # add true
               df = m-1,  # correct df
               riv = Inf, # correct riv
               std.error = sqrt(t), # standard error
               statistic = estimate / std.error, # test statistic
               p.value = 2 * (pt(abs(statistic), 
                                 pmax(df, 0.001), 
                                 lower.tail = FALSE)), # correct p.value
               `2.5 %` = estimate - qt(.975, df) * std.error, # lower bound CI
               `97.5 %` = estimate + qt(.975, df) * std.error, # upper bound CI
               cov = `2.5 %` < true & true < `97.5 %`, # coverage
               bias = estimate - true) %>% # bias
        select(term, m, true, estimate, std.error, statistic, p.value, 
               riv, `2.5 %`, `97.5 %`, cov, bias) %>% 
        column_to_rownames("term") # `term` as rownames
  ) 

Results3_MCAR_10 <- 
  mbased_finite_apollo_MCAR_10[21:30] %>% 
  map(~.x %>% # for every simulation
        complete("all") %>% 
        map(~.x %>% # for every imputation
              stats_function() %>% # do stats function
              prepare_coxph_data(apollo = .x) %$% # prepare coxph
              coxph(Surv(time, status) ~ 
                      reciprocity + 
                      indegreeSender + 
                      outdegreeReceiver + sameLoc)) %>%
        pool(custom.t = ".data$b + .data$b / .data$m") %>% # pool coefficients 
        .$pooled %>% # extract table of pooled coefficients
        mutate(true = true, # add true
               df = m-1,  # correct df
               riv = Inf, # correct riv
               std.error = sqrt(t), # standard error
               statistic = estimate / std.error, # test statistic
               p.value = 2 * (pt(abs(statistic), 
                                 pmax(df, 0.001), 
                                 lower.tail = FALSE)), # correct p.value
               `2.5 %` = estimate - qt(.975, df) * std.error, # lower bound CI
               `97.5 %` = estimate + qt(.975, df) * std.error, # upper bound CI
               cov = `2.5 %` < true & true < `97.5 %`, # coverage
               bias = estimate - true) %>% # bias
        select(term, m, true, estimate, std.error, statistic, p.value, 
               riv, `2.5 %`, `97.5 %`, cov, bias) %>% 
        column_to_rownames("term") # `term` as rownames
  )

Results4_MCAR_10 <- 
  mbased_finite_apollo_MCAR_10[31:40] %>% 
  map(~.x %>% # for every simulation
        complete("all") %>% 
        map(~.x %>% # for every imputation
              stats_function() %>% # do stats function
              prepare_coxph_data(apollo = .x) %$% # prepare coxph
              coxph(Surv(time, status) ~ 
                      reciprocity + 
                      indegreeSender + 
                      outdegreeReceiver + sameLoc)) %>%
        pool(custom.t = ".data$b + .data$b / .data$m") %>% # pool coefficients 
        .$pooled %>% # extract table of pooled coefficients
        mutate(true = true, # add true
               df = m-1,  # correct df
               riv = Inf, # correct riv
               std.error = sqrt(t), # standard error
               statistic = estimate / std.error, # test statistic
               p.value = 2 * (pt(abs(statistic), 
                                 pmax(df, 0.001), 
                                 lower.tail = FALSE)), # correct p.value
               `2.5 %` = estimate - qt(.975, df) * std.error, # lower bound CI
               `97.5 %` = estimate + qt(.975, df) * std.error, # upper bound CI
               cov = `2.5 %` < true & true < `97.5 %`, # coverage
               bias = estimate - true) %>% # bias
        select(term, m, true, estimate, std.error, statistic, p.value, 
               riv, `2.5 %`, `97.5 %`, cov, bias) %>% 
        column_to_rownames("term") # `term` as rownames
  )

Results5_MCAR_10 <- 
  mbased_finite_apollo_MCAR_10[41:50] %>% 
  map(~.x %>% # for every simulation
        complete("all") %>% 
        map(~.x %>% # for every imputation
              stats_function() %>% # do stats function
              prepare_coxph_data(apollo = .x) %$% # prepare coxph
              coxph(Surv(time, status) ~ 
                      reciprocity + 
                      indegreeSender + 
                      outdegreeReceiver + sameLoc)) %>%
        pool(custom.t = ".data$b + .data$b / .data$m") %>% # pool coefficients 
        .$pooled %>% # extract table of pooled coefficients
        mutate(true = true, # add true
               df = m-1,  # correct df
               riv = Inf, # correct riv
               std.error = sqrt(t), # standard error
               statistic = estimate / std.error, # test statistic
               p.value = 2 * (pt(abs(statistic), 
                                 pmax(df, 0.001), 
                                 lower.tail = FALSE)), # correct p.value
               `2.5 %` = estimate - qt(.975, df) * std.error, # lower bound CI
               `97.5 %` = estimate + qt(.975, df) * std.error, # upper bound CI
               cov = `2.5 %` < true & true < `97.5 %`, # coverage
               bias = estimate - true) %>% # bias
        select(term, m, true, estimate, std.error, statistic, p.value, 
               riv, `2.5 %`, `97.5 %`, cov, bias) %>% 
        column_to_rownames("term") # `term` as rownames
  )

Results6_MCAR_10 <- 
  mbased_finite_apollo_MCAR_10[51:60] %>% 
  map(~.x %>% # for every simulation
        complete("all") %>% 
        map(~.x %>% # for every imputation
              stats_function() %>% # do stats function
              prepare_coxph_data(apollo = .x) %$% # prepare coxph
              coxph(Surv(time, status) ~ 
                      reciprocity + 
                      indegreeSender + 
                      outdegreeReceiver + sameLoc)) %>%
        pool(custom.t = ".data$b + .data$b / .data$m") %>% # pool coefficients 
        .$pooled %>% # extract table of pooled coefficients
        mutate(true = true, # add true
               df = m-1,  # correct df
               riv = Inf, # correct riv
               std.error = sqrt(t), # standard error
               statistic = estimate / std.error, # test statistic
               p.value = 2 * (pt(abs(statistic), 
                                 pmax(df, 0.001), 
                                 lower.tail = FALSE)), # correct p.value
               `2.5 %` = estimate - qt(.975, df) * std.error, # lower bound CI
               `97.5 %` = estimate + qt(.975, df) * std.error, # upper bound CI
               cov = `2.5 %` < true & true < `97.5 %`, # coverage
               bias = estimate - true) %>% # bias
        select(term, m, true, estimate, std.error, statistic, p.value, 
               riv, `2.5 %`, `97.5 %`, cov, bias) %>% 
        column_to_rownames("term") # `term` as rownames
  )

Results7_MCAR_10 <- 
  mbased_finite_apollo_MCAR_10[61:70] %>% 
  map(~.x %>% # for every simulation
        complete("all") %>% 
        map(~.x %>% # for every imputation
              stats_function() %>% # do stats function
              prepare_coxph_data(apollo = .x) %$% # prepare coxph
              coxph(Surv(time, status) ~ 
                      reciprocity + 
                      indegreeSender + 
                      outdegreeReceiver + sameLoc)) %>%
        pool(custom.t = ".data$b + .data$b / .data$m") %>% # pool coefficients 
        .$pooled %>% # extract table of pooled coefficients
        mutate(true = true, # add true
               df = m-1,  # correct df
               riv = Inf, # correct riv
               std.error = sqrt(t), # standard error
               statistic = estimate / std.error, # test statistic
               p.value = 2 * (pt(abs(statistic), 
                                 pmax(df, 0.001), 
                                 lower.tail = FALSE)), # correct p.value
               `2.5 %` = estimate - qt(.975, df) * std.error, # lower bound CI
               `97.5 %` = estimate + qt(.975, df) * std.error, # upper bound CI
               cov = `2.5 %` < true & true < `97.5 %`, # coverage
               bias = estimate - true) %>% # bias
        select(term, m, true, estimate, std.error, statistic, p.value, 
               riv, `2.5 %`, `97.5 %`, cov, bias) %>% 
        column_to_rownames("term") # `term` as rownames
  )

Results8_MCAR_10 <- 
  mbased_finite_apollo_MCAR_10[71:80] %>% 
  map(~.x %>% # for every simulation
        complete("all") %>% 
        map(~.x %>% # for every imputation
              stats_function() %>% # do stats function
              prepare_coxph_data(apollo = .x) %$% # prepare coxph
              coxph(Surv(time, status) ~ 
                      reciprocity + 
                      indegreeSender + 
                      outdegreeReceiver + sameLoc)) %>%
        pool(custom.t = ".data$b + .data$b / .data$m") %>% # pool coefficients 
        .$pooled %>% # extract table of pooled coefficients
        mutate(true = true, # add true
               df = m-1,  # correct df
               riv = Inf, # correct riv
               std.error = sqrt(t), # standard error
               statistic = estimate / std.error, # test statistic
               p.value = 2 * (pt(abs(statistic), 
                                 pmax(df, 0.001), 
                                 lower.tail = FALSE)), # correct p.value
               `2.5 %` = estimate - qt(.975, df) * std.error, # lower bound CI
               `97.5 %` = estimate + qt(.975, df) * std.error, # upper bound CI
               cov = `2.5 %` < true & true < `97.5 %`, # coverage
               bias = estimate - true) %>% # bias
        select(term, m, true, estimate, std.error, statistic, p.value, 
               riv, `2.5 %`, `97.5 %`, cov, bias) %>% 
        column_to_rownames("term") # `term` as rownames
  )

Results9_MCAR_10 <- 
  mbased_finite_apollo_MCAR_10[81:90] %>% 
  map(~.x %>% # for every simulation
        complete("all") %>% 
        map(~.x %>% # for every imputation
              stats_function() %>% # do stats function
              prepare_coxph_data(apollo = .x) %$% # prepare coxph
              coxph(Surv(time, status) ~ 
                      reciprocity + 
                      indegreeSender + 
                      outdegreeReceiver + sameLoc)) %>%
        pool(custom.t = ".data$b + .data$b / .data$m") %>% # pool coefficients 
        .$pooled %>% # extract table of pooled coefficients
        mutate(true = true, # add true
               df = m-1,  # correct df
               riv = Inf, # correct riv
               std.error = sqrt(t), # standard error
               statistic = estimate / std.error, # test statistic
               p.value = 2 * (pt(abs(statistic), 
                                 pmax(df, 0.001), 
                                 lower.tail = FALSE)), # correct p.value
               `2.5 %` = estimate - qt(.975, df) * std.error, # lower bound CI
               `97.5 %` = estimate + qt(.975, df) * std.error, # upper bound CI
               cov = `2.5 %` < true & true < `97.5 %`, # coverage
               bias = estimate - true) %>% # bias
        select(term, m, true, estimate, std.error, statistic, p.value, 
               riv, `2.5 %`, `97.5 %`, cov, bias) %>% 
        column_to_rownames("term") # `term` as rownames
  )

Results10_MCAR_10 <- 
  mbased_finite_apollo_MCAR_10[91:100] %>% 
  map(~.x %>% # for every simulation
        complete("all") %>% 
        map(~.x %>% # for every imputation
              stats_function() %>% # do stats function
              prepare_coxph_data(apollo = .x) %$% # prepare coxph
              coxph(Surv(time, status) ~ 
                      reciprocity + 
                      indegreeSender + 
                      outdegreeReceiver + sameLoc)) %>%
        pool(custom.t = ".data$b + .data$b / .data$m") %>% # pool coefficients 
        .$pooled %>% # extract table of pooled coefficients
        mutate(true = true, # add true
               df = m-1,  # correct df
               riv = Inf, # correct riv
               std.error = sqrt(t), # standard error
               statistic = estimate / std.error, # test statistic
               p.value = 2 * (pt(abs(statistic), 
                                 pmax(df, 0.001), 
                                 lower.tail = FALSE)), # correct p.value
               `2.5 %` = estimate - qt(.975, df) * std.error, # lower bound CI
               `97.5 %` = estimate + qt(.975, df) * std.error, # upper bound CI
               cov = `2.5 %` < true & true < `97.5 %`, # coverage
               bias = estimate - true) %>% # bias
        select(term, m, true, estimate, std.error, statistic, p.value, 
               riv, `2.5 %`, `97.5 %`, cov, bias) %>% 
        column_to_rownames("term") # `term` as rownames
  )


###### Running the REM on all simulations MAR
Results1_MAR_10 <- 
  mbased_finite_apollo_MAR_10[1:10] %>% 
  map(~.x %>% # for every simulation
        complete("all") %>% 
        map(~.x %>% # for every imputation
              stats_function() %>% # do stats function
              prepare_coxph_data(apollo = .x) %$% # prepare coxph
              coxph(Surv(time, status) ~ 
                      reciprocity + 
                      indegreeSender + 
                      outdegreeReceiver + sameLoc)) %>%
        pool(custom.t = ".data$b + .data$b / .data$m") %>% # pool coefficients
        .$pooled %>% # extract table of pooled coefficients
        mutate(true = true, # add true
               df = m-1,  # correct df
               riv = Inf, # correct riv
               std.error = sqrt(t), # standard error
               statistic = estimate / std.error, # test statistic
               p.value = 2 * (pt(abs(statistic), 
                                 pmax(df, 0.001), 
                                 lower.tail = FALSE)), # correct p.value
               `2.5 %` = estimate - qt(.975, df) * std.error, # lower bound CI
               `97.5 %` = estimate + qt(.975, df) * std.error, # upper bound CI
               cov = `2.5 %` < true & true < `97.5 %`, # coverage
               bias = estimate - true) %>% # bias
        select(term, m, true, estimate, std.error, statistic, p.value, 
               riv, `2.5 %`, `97.5 %`, cov, bias) %>% 
        column_to_rownames("term") # `term` as rownames
  )

Results2_MAR_10 <- 
  mbased_finite_apollo_MAR_10[11:20] %>% 
  map(~.x %>% # for every simulation
        complete("all") %>% 
        map(~.x %>% # for every imputation
              stats_function() %>% # do stats function
              prepare_coxph_data(apollo = .x) %$% # prepare coxph
              coxph(Surv(time, status) ~ 
                      reciprocity + 
                      indegreeSender +
                      outdegreeReceiver + sameLoc)) %>%
        pool(custom.t = ".data$b + .data$b / .data$m") %>% # pool coefficients 
        .$pooled %>% # extract table of pooled coefficients
        mutate(true = true, # add true
               df = m-1,  # correct df
               riv = Inf, # correct riv
               std.error = sqrt(t), # standard error
               statistic = estimate / std.error, # test statistic
               p.value = 2 * (pt(abs(statistic), 
                                 pmax(df, 0.001), 
                                 lower.tail = FALSE)), # correct p.value
               `2.5 %` = estimate - qt(.975, df) * std.error, # lower bound CI
               `97.5 %` = estimate + qt(.975, df) * std.error, # upper bound CI
               cov = `2.5 %` < true & true < `97.5 %`, # coverage
               bias = estimate - true) %>% # bias
        select(term, m, true, estimate, std.error, statistic, p.value, 
               riv, `2.5 %`, `97.5 %`, cov, bias) %>% 
        column_to_rownames("term") # `term` as rownames
  ) 

Results3_MAR_10 <- 
  mbased_finite_apollo_MAR_10[21:30] %>% 
  map(~.x %>% # for every simulation
        complete("all") %>% 
        map(~.x %>% # for every imputation
              stats_function() %>% # do stats function
              prepare_coxph_data(apollo = .x) %$% # prepare coxph
              coxph(Surv(time, status) ~ 
                      reciprocity + 
                      indegreeSender + 
                      outdegreeReceiver + sameLoc)) %>%
        pool(custom.t = ".data$b + .data$b / .data$m") %>% # pool coefficients 
        .$pooled %>% # extract table of pooled coefficients
        mutate(true = true, # add true
               df = m-1,  # correct df
               riv = Inf, # correct riv
               std.error = sqrt(t), # standard error
               statistic = estimate / std.error, # test statistic
               p.value = 2 * (pt(abs(statistic), 
                                 pmax(df, 0.001), 
                                 lower.tail = FALSE)), # correct p.value
               `2.5 %` = estimate - qt(.975, df) * std.error, # lower bound CI
               `97.5 %` = estimate + qt(.975, df) * std.error, # upper bound CI
               cov = `2.5 %` < true & true < `97.5 %`, # coverage
               bias = estimate - true) %>% # bias
        select(term, m, true, estimate, std.error, statistic, p.value, 
               riv, `2.5 %`, `97.5 %`, cov, bias) %>% 
        column_to_rownames("term") # `term` as rownames
  )

Results4_MAR_10 <- 
  mbased_finite_apollo_MAR_10[31:40] %>% 
  map(~.x %>% # for every simulation
        complete("all") %>% 
        map(~.x %>% # for every imputation
              stats_function() %>% # do stats function
              prepare_coxph_data(apollo = .x) %$% # prepare coxph
              coxph(Surv(time, status) ~ 
                      reciprocity + 
                      indegreeSender + 
                      outdegreeReceiver + sameLoc)) %>%
        pool(custom.t = ".data$b + .data$b / .data$m") %>% # pool coefficients 
        .$pooled %>% # extract table of pooled coefficients
        mutate(true = true, # add true
               df = m-1,  # correct df
               riv = Inf, # correct riv
               std.error = sqrt(t), # standard error
               statistic = estimate / std.error, # test statistic
               p.value = 2 * (pt(abs(statistic), 
                                 pmax(df, 0.001), 
                                 lower.tail = FALSE)), # correct p.value
               `2.5 %` = estimate - qt(.975, df) * std.error, # lower bound CI
               `97.5 %` = estimate + qt(.975, df) * std.error, # upper bound CI
               cov = `2.5 %` < true & true < `97.5 %`, # coverage
               bias = estimate - true) %>% # bias
        select(term, m, true, estimate, std.error, statistic, p.value, 
               riv, `2.5 %`, `97.5 %`, cov, bias) %>% 
        column_to_rownames("term") # `term` as rownames
  )

Results5_MAR_10 <- 
  mbased_finite_apollo_MAR_10[41:50] %>% 
  map(~.x %>% # for every simulation
        complete("all") %>% 
        map(~.x %>% # for every imputation
              stats_function() %>% # do stats function
              prepare_coxph_data(apollo = .x) %$% # prepare coxph
              coxph(Surv(time, status) ~ 
                      reciprocity + 
                      indegreeSender + 
                      outdegreeReceiver + sameLoc)) %>%
        pool(custom.t = ".data$b + .data$b / .data$m") %>% # pool coefficients 
        .$pooled %>% # extract table of pooled coefficients
        mutate(true = true, # add true
               df = m-1,  # correct df
               riv = Inf, # correct riv
               std.error = sqrt(t), # standard error
               statistic = estimate / std.error, # test statistic
               p.value = 2 * (pt(abs(statistic), 
                                 pmax(df, 0.001), 
                                 lower.tail = FALSE)), # correct p.value
               `2.5 %` = estimate - qt(.975, df) * std.error, # lower bound CI
               `97.5 %` = estimate + qt(.975, df) * std.error, # upper bound CI
               cov = `2.5 %` < true & true < `97.5 %`, # coverage
               bias = estimate - true) %>% # bias
        select(term, m, true, estimate, std.error, statistic, p.value, 
               riv, `2.5 %`, `97.5 %`, cov, bias) %>% 
        column_to_rownames("term") # `term` as rownames
  )

Results6_MAR_10 <- 
  mbased_finite_apollo_MAR_10[51:60] %>% 
  map(~.x %>% # for every simulation
        complete("all") %>% 
        map(~.x %>% # for every imputation
              stats_function() %>% # do stats function
              prepare_coxph_data(apollo = .x) %$% # prepare coxph
              coxph(Surv(time, status) ~ 
                      reciprocity + 
                      indegreeSender + 
                      outdegreeReceiver + sameLoc)) %>%
        pool(custom.t = ".data$b + .data$b / .data$m") %>% # pool coefficients 
        .$pooled %>% # extract table of pooled coefficients
        mutate(true = true, # add true
               df = m-1,  # correct df
               riv = Inf, # correct riv
               std.error = sqrt(t), # standard error
               statistic = estimate / std.error, # test statistic
               p.value = 2 * (pt(abs(statistic), 
                                 pmax(df, 0.001), 
                                 lower.tail = FALSE)), # correct p.value
               `2.5 %` = estimate - qt(.975, df) * std.error, # lower bound CI
               `97.5 %` = estimate + qt(.975, df) * std.error, # upper bound CI
               cov = `2.5 %` < true & true < `97.5 %`, # coverage
               bias = estimate - true) %>% # bias
        select(term, m, true, estimate, std.error, statistic, p.value, 
               riv, `2.5 %`, `97.5 %`, cov, bias) %>% 
        column_to_rownames("term") # `term` as rownames
  )

Results7_MAR_10 <- 
  mbased_finite_apollo_MAR_10[61:70] %>% 
  map(~.x %>% # for every simulation
        complete("all") %>% 
        map(~.x %>% # for every imputation
              stats_function() %>% # do stats function
              prepare_coxph_data(apollo = .x) %$% # prepare coxph
              coxph(Surv(time, status) ~ 
                      reciprocity + 
                      indegreeSender + 
                      outdegreeReceiver + sameLoc)) %>%
        pool(custom.t = ".data$b + .data$b / .data$m") %>% # pool coefficients 
        .$pooled %>% # extract table of pooled coefficients
        mutate(true = true, # add true
               df = m-1,  # correct df
               riv = Inf, # correct riv
               std.error = sqrt(t), # standard error
               statistic = estimate / std.error, # test statistic
               p.value = 2 * (pt(abs(statistic), 
                                 pmax(df, 0.001), 
                                 lower.tail = FALSE)), # correct p.value
               `2.5 %` = estimate - qt(.975, df) * std.error, # lower bound CI
               `97.5 %` = estimate + qt(.975, df) * std.error, # upper bound CI
               cov = `2.5 %` < true & true < `97.5 %`, # coverage
               bias = estimate - true) %>% # bias
        select(term, m, true, estimate, std.error, statistic, p.value, 
               riv, `2.5 %`, `97.5 %`, cov, bias) %>% 
        column_to_rownames("term") # `term` as rownames
  )

Results8_MAR_10 <- 
  mbased_finite_apollo_MAR_10[71:80] %>% 
  map(~.x %>% # for every simulation
        complete("all") %>% 
        map(~.x %>% # for every imputation
              stats_function() %>% # do stats function
              prepare_coxph_data(apollo = .x) %$% # prepare coxph
              coxph(Surv(time, status) ~ 
                      reciprocity + 
                      indegreeSender + 
                      outdegreeReceiver + sameLoc)) %>%
        pool(custom.t = ".data$b + .data$b / .data$m") %>% # pool coefficients 
        .$pooled %>% # extract table of pooled coefficients
        mutate(true = true, # add true
               df = m-1,  # correct df
               riv = Inf, # correct riv
               std.error = sqrt(t), # standard error
               statistic = estimate / std.error, # test statistic
               p.value = 2 * (pt(abs(statistic), 
                                 pmax(df, 0.001), 
                                 lower.tail = FALSE)), # correct p.value
               `2.5 %` = estimate - qt(.975, df) * std.error, # lower bound CI
               `97.5 %` = estimate + qt(.975, df) * std.error, # upper bound CI
               cov = `2.5 %` < true & true < `97.5 %`, # coverage
               bias = estimate - true) %>% # bias
        select(term, m, true, estimate, std.error, statistic, p.value, 
               riv, `2.5 %`, `97.5 %`, cov, bias) %>% 
        column_to_rownames("term") # `term` as rownames
  )

Results9_MAR_10 <- 
  mbased_finite_apollo_MAR_10[81:90] %>% 
  map(~.x %>% # for every simulation
        complete("all") %>% 
        map(~.x %>% # for every imputation
              stats_function() %>% # do stats function
              prepare_coxph_data(apollo = .x) %$% # prepare coxph
              coxph(Surv(time, status) ~ 
                      reciprocity + 
                      indegreeSender + 
                      outdegreeReceiver + sameLoc)) %>%
        pool(custom.t = ".data$b + .data$b / .data$m") %>% # pool coefficients 
        .$pooled %>% # extract table of pooled coefficients
        mutate(true = true, # add true
               df = m-1,  # correct df
               riv = Inf, # correct riv
               std.error = sqrt(t), # standard error
               statistic = estimate / std.error, # test statistic
               p.value = 2 * (pt(abs(statistic), 
                                 pmax(df, 0.001), 
                                 lower.tail = FALSE)), # correct p.value
               `2.5 %` = estimate - qt(.975, df) * std.error, # lower bound CI
               `97.5 %` = estimate + qt(.975, df) * std.error, # upper bound CI
               cov = `2.5 %` < true & true < `97.5 %`, # coverage
               bias = estimate - true) %>% # bias
        select(term, m, true, estimate, std.error, statistic, p.value, 
               riv, `2.5 %`, `97.5 %`, cov, bias) %>% 
        column_to_rownames("term") # `term` as rownames
  )

Results10_MAR_10 <- 
  mbased_finite_apollo_MAR_10[91:100] %>% 
  map(~.x %>% # for every simulation
        complete("all") %>% 
        map(~.x %>% # for every imputation
              stats_function() %>% # do stats function
              prepare_coxph_data(apollo = .x) %$% # prepare coxph
              coxph(Surv(time, status) ~ 
                      reciprocity + 
                      indegreeSender + 
                      outdegreeReceiver + sameLoc)) %>%
        pool(custom.t = ".data$b + .data$b / .data$m") %>% # pool coefficients 
        .$pooled %>% # extract table of pooled coefficients
        mutate(true = true, # add true
               df = m-1,  # correct df
               riv = Inf, # correct riv
               std.error = sqrt(t), # standard error
               statistic = estimate / std.error, # test statistic
               p.value = 2 * (pt(abs(statistic), 
                                 pmax(df, 0.001), 
                                 lower.tail = FALSE)), # correct p.value
               `2.5 %` = estimate - qt(.975, df) * std.error, # lower bound CI
               `97.5 %` = estimate + qt(.975, df) * std.error, # upper bound CI
               cov = `2.5 %` < true & true < `97.5 %`, # coverage
               bias = estimate - true) %>% # bias
        select(term, m, true, estimate, std.error, statistic, p.value, 
               riv, `2.5 %`, `97.5 %`, cov, bias) %>% 
        column_to_rownames("term") # `term` as rownames
  )

##### Combining Results
Results_MCAR_10 <- list(Results1_MCAR_10,
                     Results2_MCAR_10,
                     Results3_MCAR_10,
                     Results4_MCAR_10,
                     Results5_MCAR_10,
                     Results6_MCAR_10,
                     Results7_MCAR_10,
                     Results8_MCAR_10,
                     Results9_MCAR_10,
                     Results10_MCAR_10) %>%
  purrr::flatten()

##### Combining Results
Results_MAR_10 <- list(Results1_MAR_10,
                    Results2_MAR_10,
                    Results3_MAR_10,
                    Results4_MAR_10,
                    Results5_MAR_10,
                    Results6_MAR_10,
                    Results7_MAR_10,
                    Results8_MAR_10,
                    Results9_MAR_10,
                    Results10_MAR_10) %>%
  purrr::flatten()

# Save the result to an RDS file
saveRDS(Results_MCAR_10, file = "Results_MCAR_10.rds")
saveRDS(Results_MAR_10, file = "Results_MAR_10.rds")